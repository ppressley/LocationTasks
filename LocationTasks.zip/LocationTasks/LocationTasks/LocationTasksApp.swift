//
//  LocationTasksApp.swift
//  LocationTasks
//
//  Created by Student on 11/15/23.
//

import SwiftUI

@main
struct LocationTasksApp: App {

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
