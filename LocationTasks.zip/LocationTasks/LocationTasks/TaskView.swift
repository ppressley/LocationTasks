//
//  TaskView.swift
//  LocationTasks
//
//  Created by Student on 11/29/23.
//

import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct taskView: View {
    @Environment(\.presentationMode) var presentationMode

    @Binding var tasks: [Task]
    
    var body: some View {
        ZStack {
            Color.cyan
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text("**Tasks**")
                        .font(.system(size: 28))
                        .foregroundColor(.red)
                }
                HStack {
                    Button("**Back**") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 12))
                    .tint(.red)
                    .padding()
                    Spacer()
                }
                Spacer()
                    .navigationBarHidden(true)
                NavigationStack {
                    ZStack {
                        LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.white]), startPoint: .top, endPoint: .bottom)
                            .edgesIgnoringSafeArea(.all)
                        List {
                            ForEach(tasks, id: \.self) { task in
                                VStack(alignment: .leading) {
                                    Text(task.name)
                                        .font(.headline)
                                        .foregroundColor(.red)
                                    Text(task.description)
                                        .font(.subheadline)
                                        .foregroundColor(.white)
                                    Text("**Due Date: \(task.dueDate, style: .date)**")
                                        .font(.subheadline)
                                        .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                                }
                                .listStyle(PlainListStyle())
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .listRowBackground(
                                    LinearGradient(
                                        colors: [.cyan, .blue],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                            }
                            .onDelete(perform: delete)
                        }
                        .scrollContentBackground(.hidden)
                    }
                }
            }
        }
    }
    func delete(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
        saveTasks()
    }
    func saveTasks() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }
}
