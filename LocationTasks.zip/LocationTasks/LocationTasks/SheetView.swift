//
//  SheetView.swift
//  LocationTasks
//
//  Created by Student on 11/29/23.
//

import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct SheetContent: View {
    @Binding var taskName: String
    @Binding var taskDescription: String
    @Binding var dueDate: Date
    @Binding var isSheetPresented: Bool
    @Binding var tasks: [Task]
    @Binding var currentLocation: CLLocationCoordinate2D?
    @Binding var region: MKCoordinateRegion?

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.blue]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text("**Create a Task**")
                        .font(.system(size: 28))
                        .foregroundColor(.white)
                        .padding()
                }

                TextField("Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                TextField("Task Description", text: $taskDescription)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                DatePicker("Due Date", selection: $dueDate, in: Date()...)
                    .datePickerStyle(WheelDatePickerStyle())
                    .labelsHidden()
                    .padding()

                HStack {
                    Button("Cancel") {
                        isSheetPresented = false
                    }
                    .buttonStyle(.bordered)
                    .font(.system(size: 16))
                    .foregroundColor(.white)
                    .tint(.red)
                    .padding()

                    Spacer()

                    Button("Confirm") {
                        let defaultLocation = CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172)
                        let newTask = Task(
                            name: taskName,
                            description: taskDescription,
                            dueDate: dueDate,
                            latitude: currentLocation?.latitude ?? defaultLocation.latitude,
                            longitude: currentLocation?.longitude ?? defaultLocation.longitude
                        )
                        tasks.append(newTask)
                        saveTasks()

                        // Update the region with the new task's location
                        if let location = currentLocation {
                            region = MKCoordinateRegion(
                                center: location,
                                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                            )

                            // Add an annotation to the map
                            let annotation = MKPointAnnotation()
                            annotation.coordinate = location
                            annotation.title = newTask.name
                            annotation.subtitle = newTask.description

                            // Notify the map to update the UI
                            NotificationCenter.default.post(name: Notification.Name("AddAnnotation"), object: annotation)
                        }

                        isSheetPresented = false
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 16))
                    .tint(.red)
                    .padding()
                    .disabled(taskName.isEmpty || taskDescription.isEmpty)
                }
            }
            .padding()
        }
    }
    func saveTasks() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }
    func deleteTask(at index: Int) {
        tasks.remove(at: index)
        saveTasks()
    }
}
