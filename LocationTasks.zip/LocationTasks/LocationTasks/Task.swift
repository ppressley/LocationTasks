//
//  Task.swift
//  LocationTasks
//
//  Created by Student on 11/29/23.
//

import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct Task: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var description: String
    var dueDate: Date
    var latitude: Double
    var longitude: Double

    var locationCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}
