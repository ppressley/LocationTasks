//
//  ContentView.swift
//  LocationTasks
//
//  Created by Student on 11/15/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView(){
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
