import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI



struct ContentView: View {
    @State private var mapRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    )

    @State private var isSheetPresented = false
    @State private var taskName = ""
    @State private var taskDescription = ""
    @State private var dueDate = Date()
    @State private var latitude: Double = 0.0
    @State private var longitude: Double = 0.0
    @State private var tasks: [Task] = []
    @State private var annotations: [MKPointAnnotation] = []
    @State private var region: MKCoordinateRegion?
    @State private var currentLocation: CLLocationCoordinate2D?
    
    @StateObject private var locationManager = LocationManager()
    
    var body: some View {
        NavigationView {
            ZStack {
                if let location = locationManager.location {
                    Text("Your location: \(location.latitude), \(location.longitude)")
                    
                    Map(coordinateRegion: $mapRegion, interactionModes: .all, showsUserLocation: true, userTrackingMode: .constant(.follow), annotationItems: tasks) { task in
                        MapAnnotation(coordinate: task.locationCoordinate) {
                            Image(systemName: "mappin.and.ellipse")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 40)
                                .foregroundColor(.red)
                        }
                    }
                    .ignoresSafeArea()
                    .gesture(DragGesture())
                    .onLongPressGesture() {
                        isSheetPresented = true
                    }
                }
                else {
                    ProgressView()
                        .scaleEffect(3.74)
                        .tint(.blue)

                }

                VStack {
                    HStack {
                        Text("**LocationTasks**")
                            .font(.system(size: 28))
                            .foregroundColor(.red)
                    }
                    HStack {
                        Spacer()
                        NavigationLink("**View Tasks**", destination: taskView(tasks: $tasks))
                            .buttonStyle(.borderedProminent)
                            .font(.system(size: 12))
                            .tint(.red)
                            .padding()
                    }
                    Spacer()
                }
            }
            .onAppear {
                            locationManager.requestLocation()
                        }
            .sheet(isPresented: $isSheetPresented, onDismiss: {
                taskName = ""
                taskDescription = ""
                dueDate = Date()
            }) {
                SheetContent(
                    taskName: $taskName,
                    taskDescription: $taskDescription,
                    dueDate: $dueDate,
                    latitude: $latitude,
                    longitude: $longitude,
                    isSheetPresented: $isSheetPresented,
                    tasks: $tasks,
                    currentLocation: $locationManager.location,
                    region: $region
                )
            }
        }
        .environmentObject(locationManager)
        .onAppear {
            // Load tasks from UserDefaults
            if let savedTasks = UserDefaults.standard.data(forKey: "tasks") {
                let decoder = JSONDecoder()
                if let loadedTasks = try? decoder.decode([Task].self, from: savedTasks) {
                    tasks = loadedTasks
                }
            }
            locationManager.requestLocation()
        }
    }
    func saveTasks() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }
}




class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    let manager = CLLocationManager()
    @Published var location: CLLocationCoordinate2D?
    @Published var region: MKCoordinateRegion?

    override init() {
        super.init()
        manager.delegate = self
        requestLocation()
        
        // For Preview Testing Comment This Out
        location = CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172)
    }

    func requestLocation() {
        manager.requestWhenInUseAuthorization()
        manager.requestLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first?.coordinate else { return }
        self.location = location
        self.region = MKCoordinateRegion(
            center: location,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        )
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
}



class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        // Create a UITapGestureRecognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))

        // Add the gesture recognizer to the view
        view.addGestureRecognizer(tapGesture)
    }

    // Selector method to handle the tap gesture
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        // Handle the tap gesture here
        print("Tap gesture recognized!")
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(LocationManager())
    }
}
