import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct Task: Identifiable {
    var id = UUID()
    var name: String
    var description: String
    var dueDate: Date
}

struct ContentView: View {
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )

    @State private var isSheetPresented = false
    @State private var taskName = ""
    @State private var taskDescription = ""
    @State private var dueDate = Date()

    var body: some View {
        NavigationView {
            ZStack {
                Map(coordinateRegion: $region, interactionModes: .all, showsUserLocation: true)
                    .ignoresSafeArea()
                    .gesture(DragGesture())
                    .onLongPressGesture {
                        isSheetPresented = true
                    }

                VStack {
                    HStack {
                        Text("**LocationTasks**")
                            .font(.system(size: 28))
                            .foregroundColor(.red)
                    }
                    HStack {
                        Spacer()
                        NavigationLink("**View Tasks**", destination: SecondPage())
                            .buttonStyle(.borderedProminent)
                            .font(.system(size: 12))
                            .tint(.red)
                            .padding()
                    }
                    Spacer()
                }
            }
            .sheet(isPresented: $isSheetPresented) {
                SheetContent(taskName: $taskName, taskDescription: $taskDescription, dueDate: $dueDate, isSheetPresented: $isSheetPresented)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct SecondPage: View {
    @Environment(\.presentationMode) var presentationMode

    @State private var tasks: [Task] = []
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.white]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            VStack {
                HStack {
                    Text("**Tasks**")
                        .font(.system(size: 28))
                        .foregroundColor(.red)
                }
                HStack {
                    Button("**Back**") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 12))
                    .tint(.red)
                    .padding()
                    Spacer()
                }
                Spacer()
                    .navigationBarHidden(true)
                
                List(tasks) { task in
                                  VStack(alignment: .leading) {
                                      Text(task.name)
                                          .font(.headline)
                                          .foregroundColor(.red)
                                      Text(task.description)
                                          .font(.subheadline)
                                          .foregroundColor(.white)
                                      Text("**Due Date: \(task.dueDate, style: .date)**")
                                          .font(.subheadline)
                                          .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                                }
                                .listStyle(PlainListStyle())
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .listRowBackground(
                                    LinearGradient(
                                        colors: [.cyan, .blue],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )

                }
                .scrollContentBackground(.hidden)
                
            }
        }
        .onAppear {
            // Test Tasks
            tasks.append(Task(name: "Go Get Dinner", description: "I'm hungry, I'm tryna eat.", dueDate: Date().addingTimeInterval(86400))) // Tomorrow
            tasks.append(Task(name: "Camping Trip", description: "Going out to the woods and sleeping.", dueDate: Date().addingTimeInterval(172800))) // Day after tomorrow
        }
    }
}

struct SheetContent: View {
    @Binding var taskName: String
    @Binding var taskDescription: String
    @Binding var dueDate: Date
    @Binding var isSheetPresented: Bool

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.blue]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text("**Create a Task**")
                        .font(.system(size: 28))
                        .foregroundColor(.white)
                        .padding()
                }

                TextField("Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                TextField("Task Description", text: $taskDescription)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                DatePicker("Due Date", selection: $dueDate, in: Date()...)
                    .datePickerStyle(WheelDatePickerStyle())
                    .labelsHidden()
                    .padding()

                HStack {
                    Button("Cancel") {
                        isSheetPresented = false
                    }
                    .buttonStyle(.bordered)
                    .font(.system(size: 16))
                    .foregroundColor(.white)
                    .tint(.red)
                    .padding()

                    Spacer()

                    Button("Confirm") {
                        print("Task Name: \(taskName)")
                        print("Task Description: \(taskDescription)")
                        print("Due Date: \(dueDate)")
                        isSheetPresented = false
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 16))
                    .tint(.red)
                    .padding()
                }
            }
            .padding()
        }
    }
}

