import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct Task: Identifiable {
    var id = UUID()
    var name: String
    var description: String
    var dueDate: Date
    var latitude: Double
    var longitude: Double

    var locationCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct ContentView: View {
    @State private var mapRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    )

    @State private var isSheetPresented = false
    @State private var taskName = ""
    @State private var taskDescription = ""
    @State private var dueDate = Date()
    @State private var tasks: [Task] = []
    @State private var region: MKCoordinateRegion?

    @StateObject private var locationManager = LocationManager()
    @State private var currentLocation: CLLocationCoordinate2D?
    
    var body: some View {
        NavigationView {
            ZStack {
                Map(coordinateRegion: $mapRegion, interactionModes: .all, showsUserLocation: true)
                    .ignoresSafeArea()
                    .gesture( TapGesture().onEnded { tap in
                        let coordinate: CLLocationCoordinate2D = mapRegion.convert(tap.location, toCoordinateFrom: nil)
                                                   tappedLocation = coordinate
                                                   isSheetPresented = true
                        }
                    )
                    .onLongPressGesture {
                        isSheetPresented = true
                    }


                VStack {
                    HStack {
                        Text("**LocationTasks**")
                            .font(.system(size: 28))
                            .foregroundColor(.red)
                    }
                    HStack {
                        Spacer()
                        NavigationLink("**View Tasks**", destination: SecondPage(tasks: $tasks))
                            .buttonStyle(.borderedProminent)
                            .font(.system(size: 12))
                            .tint(.red)
                            .padding()
                    }
                    Spacer()
                }
            }
            .onAppear {
                            locationManager.requestLocation()
                        }
            .sheet(isPresented: $isSheetPresented, onDismiss: {
                taskName = ""
                taskDescription = ""
                dueDate = Date()
            }) {
                SheetContent(
                    taskName: $taskName,
                    taskDescription: $taskDescription,
                    dueDate: $dueDate,
                    isSheetPresented: $isSheetPresented,
                    tasks: $tasks,
                    currentLocation: $locationManager.location, region: $region
                )
            }
        }
        .environmentObject(locationManager)
    }
}


struct SecondPage: View {
    @Environment(\.presentationMode) var presentationMode

    @Binding var tasks: [Task]
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.white]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            VStack {
                HStack {
                    Text("**Tasks**")
                        .font(.system(size: 28))
                        .foregroundColor(.red)
                }
                HStack {
                    Button("**Back**") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 12))
                    .tint(.red)
                    .padding()
                    Spacer()
                }
                Spacer()
                    .navigationBarHidden(true)
                
                List(tasks) { task in
                                  VStack(alignment: .leading) {
                                      Text(task.name)
                                          .font(.headline)
                                          .foregroundColor(.red)
                                      Text(task.description)
                                          .font(.subheadline)
                                          .foregroundColor(.white)
                                      Text("**Due Date: \(task.dueDate, style: .date)**")
                                          .font(.subheadline)
                                          .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                                }
                                .listStyle(PlainListStyle())
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .listRowBackground(
                                    LinearGradient(
                                        colors: [.cyan, .blue],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )

                }
                .scrollContentBackground(.hidden)
                
            }
        }
    }
}

struct SheetContent: View {
    @Binding var taskName: String
    @Binding var taskDescription: String
    @Binding var dueDate: Date
    @Binding var isSheetPresented: Bool
    @Binding var tasks: [Task]
    @Binding var currentLocation: CLLocationCoordinate2D?
    @Binding var region: MKCoordinateRegion?

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.blue]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text("**Create a Task**")
                        .font(.system(size: 28))
                        .foregroundColor(.white)
                        .padding()
                }

                TextField("Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                TextField("Task Description", text: $taskDescription)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                DatePicker("Due Date", selection: $dueDate, in: Date()...)
                    .datePickerStyle(WheelDatePickerStyle())
                    .labelsHidden()
                    .padding()

                HStack {
                    Button("Cancel") {
                        isSheetPresented = false
                    }
                    .buttonStyle(.bordered)
                    .font(.system(size: 16))
                    .foregroundColor(.white)
                    .tint(.red)
                    .padding()

                    Spacer()

                    Button("Confirm") {
                        guard let currentLocation = currentLocation else {
                             // Handle the case where the current location is not available
                             return
                         }

                         let newTask = Task(
                             name: taskName,
                             description: taskDescription,
                             dueDate: dueDate,
                             latitude: currentLocation.latitude,
                             longitude: currentLocation.longitude
                         )
                         tasks.append(newTask)

                         // Update the region with the new task's location
                         region = MKCoordinateRegion(
                             center: currentLocation,
                             span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                         )

                         // Add an annotation to the map
                         let annotation = MKPointAnnotation()
                         annotation.coordinate = currentLocation
                         annotation.title = newTask.name
                         annotation.subtitle = newTask.description

                         // Notify the map to update the UI
                         NotificationCenter.default.post(name: Notification.Name("AddAnnotation"), object: annotation)

                         isSheetPresented = false
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 16))
                    .tint(.red)
                    .padding()
                }
            }
            .padding()
        }
    }
}


class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    let manager = CLLocationManager()
    @Published var location: CLLocationCoordinate2D?
    
    @Published var region: MKCoordinateRegion?

    override init() {
        super.init()
        manager.delegate = self
    }

    func requestLocation() {
        manager.requestWhenInUseAuthorization()
        manager.requestLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first else { return }
        
        // Update the location and region
        self.location = location.coordinate
        self.region = MKCoordinateRegion(
            center: location.coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        )
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(LocationManager())
    }
}
