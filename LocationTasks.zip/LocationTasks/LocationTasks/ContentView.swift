import SwiftUI
import MapKit
import CoreLocation
import CoreLocationUI

struct Task: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var description: String
    var dueDate: Date
    var latitude: Double
    var longitude: Double

    var locationCoordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct ContentView: View {
    @State private var mapRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    )

    @State private var isSheetPresented = false
    @State private var taskName = ""
    @State private var taskDescription = ""
    @State private var dueDate = Date()
    @State private var tasks: [Task] = []
    @State private var annotations: [MKPointAnnotation] = []
    @State private var region: MKCoordinateRegion?

    @StateObject private var locationManager = LocationManager()
    @State private var currentLocation: CLLocationCoordinate2D?
    
    @State private var taskPins: [Task] = []
    
    var body: some View {
        NavigationView {
            ZStack {
                Map(coordinateRegion: $mapRegion, interactionModes: .all, showsUserLocation: true, annotationItems: tasks) { task in
                    MapMarker(coordinate: task.locationCoordinate, tint: .red)
                }
                    .ignoresSafeArea()
                    .gesture(DragGesture())
                    .onLongPressGesture {
                        let coordinate = mapRegion.convert(value.location, toCoordinateFrom: nil)
                        currentLocation = coordinate
                        print("New Coordinate: \(currentLocation)")
                        isSheetPresented = true
                    }

                        //.onEnded { value in
                            //let coordinate = mapRegion.center
                          //  let coordinate = mapRegion.convert(value.location, toCoordinateFrom: mapRegion)
                           // currentLocation = coordinate
                           // print(currentLocation!)
                            
                           // isSheetPresented = true
                


                VStack {
                    HStack {
                        Text("**LocationTasks**")
                            .font(.system(size: 28))
                            .foregroundColor(.red)
                    }
                    HStack {
                        Spacer()
                        NavigationLink("**View Tasks**", destination: SecondPage(tasks: $tasks))
                            .buttonStyle(.borderedProminent)
                            .font(.system(size: 12))
                            .tint(.red)
                            .padding()
                    }
                    Spacer()
                }
            }
            .onAppear {
                            locationManager.requestLocation()
                        }
            .sheet(isPresented: $isSheetPresented, onDismiss: {
                taskName = ""
                taskDescription = ""
                dueDate = Date()
            }) {
                SheetContent(
                    taskName: $taskName,
                    taskDescription: $taskDescription,
                    dueDate: $dueDate,
                    isSheetPresented: $isSheetPresented,
                    tasks: $tasks,
                    currentLocation: $locationManager.location, region: $region
                )
            }
        }
        .environmentObject(locationManager)
        .onAppear {
            // Load tasks from UserDefaults
            if let savedTasks = UserDefaults.standard.data(forKey: "tasks") {
                let decoder = JSONDecoder()
                if let loadedTasks = try? decoder.decode([Task].self, from: savedTasks) {
                    tasks = loadedTasks
                }
            }
            locationManager.requestLocation()
        }
    }
    func saveTasks() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }
}


struct SecondPage: View {
    @Environment(\.presentationMode) var presentationMode

    @Binding var tasks: [Task]
    
    var body: some View {
        ZStack {
            Color.cyan
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text("**Tasks**")
                        .font(.system(size: 28))
                        .foregroundColor(.red)
                }
                HStack {
                    Button("**Back**") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 12))
                    .tint(.red)
                    .padding()
                    Spacer()
                }
                Spacer()
                    .navigationBarHidden(true)
                NavigationStack {
                    ZStack {
                        LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.white]), startPoint: .top, endPoint: .bottom)
                            .edgesIgnoringSafeArea(.all)
                        List {
                            ForEach(tasks, id: \.self) { task in
                                VStack(alignment: .leading) {
                                    Text(task.name)
                                        .font(.headline)
                                        .foregroundColor(.red)
                                    Text(task.description)
                                        .font(.subheadline)
                                        .foregroundColor(.white)
                                    Text("**Due Date: \(task.dueDate, style: .date)**")
                                        .font(.subheadline)
                                        .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                                }
                                .listStyle(PlainListStyle())
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .listRowBackground(
                                    LinearGradient(
                                        colors: [.cyan, .blue],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                            }
                            .onDelete(perform: delete)
                        }
                        .scrollContentBackground(.hidden)
                    }
                }
            }
        }
    }
    func delete(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
        saveTasks()
    }
    func saveTasks() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }
}

struct SheetContent: View {
    @Binding var taskName: String
    @Binding var taskDescription: String
    @Binding var dueDate: Date
    @Binding var isSheetPresented: Bool
    @Binding var tasks: [Task]
    @Binding var currentLocation: CLLocationCoordinate2D?
    @Binding var region: MKCoordinateRegion?

    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.cyan, Color.blue]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
                .ignoresSafeArea()
            VStack {
                HStack {
                    Text("**Create a Task**")
                        .font(.system(size: 28))
                        .foregroundColor(.white)
                        .padding()
                }

                TextField("Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                TextField("Task Description", text: $taskDescription)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                DatePicker("Due Date", selection: $dueDate, in: Date()...)
                    .datePickerStyle(WheelDatePickerStyle())
                    .labelsHidden()
                    .padding()

                HStack {
                    Button("Cancel") {
                        isSheetPresented = false
                    }
                    .buttonStyle(.bordered)
                    .font(.system(size: 16))
                    .foregroundColor(.white)
                    .tint(.red)
                    .padding()

                    Spacer()

                    Button("Confirm") {
                        let defaultLocation = CLLocationCoordinate2D(latitude: 39.3477, longitude: -76.6172)
                        let newTask = Task(
                            name: taskName,
                            description: taskDescription,
                            dueDate: dueDate,
                            latitude: currentLocation?.latitude ?? defaultLocation.latitude,
                            longitude: currentLocation?.longitude ?? defaultLocation.longitude
                        )
                        tasks.append(newTask)
                        saveTasks()

                        // Update the region with the new task's location
                        if let location = currentLocation {
                            region = MKCoordinateRegion(
                                center: location,
                                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                            )

                            // Add an annotation to the map
                            let annotation = MKPointAnnotation()
                            annotation.coordinate = location
                            annotation.title = newTask.name
                            annotation.subtitle = newTask.description

                            // Notify the map to update the UI
                            NotificationCenter.default.post(name: Notification.Name("AddAnnotation"), object: annotation)
                        }

                        isSheetPresented = false
                    }
                    .buttonStyle(.borderedProminent)
                    .font(.system(size: 16))
                    .tint(.red)
                    .padding()
                    .disabled(taskName.isEmpty || taskDescription.isEmpty)
                }
            }
            .padding()
        }
    }
    func saveTasks() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }
    func deleteTask(at index: Int) {
        tasks.remove(at: index)
        saveTasks()
    }
}


class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    let manager = CLLocationManager()
    @Published var location: CLLocationCoordinate2D?
    @Published var region: MKCoordinateRegion?

    override init() {
        super.init()
        manager.delegate = self
        requestLocation()
    }

    func requestLocation() {
        manager.requestWhenInUseAuthorization()
        manager.requestLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.first?.coordinate else { return }
        self.location = location
        self.region = MKCoordinateRegion(
            center: location,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        )
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(LocationManager())
    }
}
